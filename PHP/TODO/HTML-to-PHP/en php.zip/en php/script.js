function cambiar() {
    var element = document.getElementById("galeria");
    element.classList.toggle("lista");
  }
  