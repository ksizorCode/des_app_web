<?php include "_includes/_header.php";?>
<? alerta('CONTACTO.php cargado'); ?>
    
    <img class="foton-cabecera playa" src="img/contacto.jpg" alt="playa">
        <h2>Contacto</h2>

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum fugiat debitis consequatur voluptate obcaecati sequi autem quaerat at aut accusamus.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum fugiat debitis consequatur voluptate obcaecati sequi autem quaerat at aut accusamus.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum fugiat debitis consequatur voluptate obcaecati sequi autem quaerat at aut accusamus.</p>
        

        <?php include "_includes/_lista.php";?>

                
            </ul>
        </div>

        <?php
    include "_includes/_footer.php";
    ?>