<?php include "_includes/_header.php";?>
<? alerta('INDEX.php cargado'); ?>
      
       <img class="foton-cabecera playa" src="img/playa_asturias.jpg" alt="playa">
        
       <?php include "_includes/_lista.php";?>

    <?php
    include "_includes/_footer.php";
    ?>