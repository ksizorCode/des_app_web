
<?php include "_includes/_header.php";?>
<? alerta('NOSOTROS.php cargado'); ?>

<!-- a partir de aqui cambiamos la página -->

        <img class="foton-cabecera playa" src="img/nosotros.jpg" alt="playa">
        <h2>Nosotros</h2>

        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veritatis, esse. Magni culpa enim voluptate a!</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veritatis, esse. Magni culpa enim voluptate a!</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veritatis, esse. Magni culpa enim voluptate a!</p>

        <?php include "_includes/_lista.php";?>

       
        <?php
    include "_includes/_footer.php";
    ?>