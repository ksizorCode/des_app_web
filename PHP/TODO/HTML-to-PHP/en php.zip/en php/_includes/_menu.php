<ul class="menu menuHeader">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="nosotros.php">Nosotros</a></li>
            <li><a href="contacto.php">Contacto</a></li>
        </ul>
        
<? alerta('MENU.php cargado'); ?>
