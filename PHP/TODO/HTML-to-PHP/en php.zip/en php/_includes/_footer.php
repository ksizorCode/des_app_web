<? alerta('FOOTER.php cargado'); ?>

</main>
    <footer>
    <?php include "_includes/_menu.php";?>
     <p>&copy;Copyright 2023.Asturies</p>
    </footer>

<script src="script.js"></script>
</body>


</html>
