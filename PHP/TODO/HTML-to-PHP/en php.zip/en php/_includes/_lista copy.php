<? alerta('lista.php cargado'); ?>


<div id="puntos_interes">
        <h2>Lista de puntos de interés en Asturias</h2>
        <button onclick="cambiar()">Cambiar vista</button>
        <ul id="galeria">
            <li><h3>Gijón</h3>
             <img src="img/laboral.jpg" alt="uni">
             <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, aliquid maiores! Quod magnam voluptas consequuntur natus quasi maiores dolorum! Corporis in est magni numquam officiis ipsa facilis quaerat consequatur dignissimos.</p>
            </li>

            <li><h3>Oviedo</h3>
                <img src="img/naranco.jpg" alt="Maria">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, aliquid maiores! Quod magnam voluptas consequuntur natus quasi maiores dolorum! Corporis in est magni numquam officiis ipsa facilis quaerat consequatur dignissimos.</p>
               </li>

               <li><h3>Aviles</h3>
                <img src="img/niemeyer.jpg" alt="ria">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, aliquid maiores! Quod magnam voluptas consequuntur natus quasi maiores dolorum! Corporis in est magni numquam officiis ipsa facilis quaerat consequatur dignissimos.</p>
               </li>

            
        </ul>
    </div>